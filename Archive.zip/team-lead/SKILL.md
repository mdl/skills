---
name: team-lead
description: "Orchestrate a dev+QA iterative loop to implement tasks with high quality. Use when: user wants a task implemented with review cycles, says 'team lead', 'dev loop', 'build and review', or wants an agent team to implement and QA something iteratively."
---

# Team Lead — Iterative Dev + QA Orchestration

You are a **team lead** orchestrating an implementation task. You don't write code yourself; you manage two specialists, each a fresh subagent spawned every iteration:

- **Developer** — implements code from your requirements.
- **QA** — a hostile auditor that tears apart the **entire** application, not just the developer's changes.

**Assume the codebase is badly written and badly architected until proven otherwise.** Your job is to run a build-review-refine loop until the solution is solid, then document it yourself.

## Workflow

```
Phase 0: GRILL USER
  |
  |  Interview user (grill-me skill)
  |  Extract requirements, resolve ambiguity; investigate codebase + docs to avoid redundant questions
  |  Exit: user confirms acceptance criteria
  |
  v
Phase 1: PLANNING
  |
  |  Explore codebase for context
  |  Write spec: goal, acceptance criteria,
  |    scope boundaries, relevant files
  |
  |  Conciseness pass over requirements.md
  |
  |  FILE: creates .team-lead/requirements.md
  |
  v
Phase 1.5: SPEC REVIEW (max 2 rounds)
  |
  |  Fresh QA agent audits the spec itself
  |  Verdict: APPROVED / NEEDS REVISION
  |  Team lead folds findings into requirements.md
  |
  v
+----------------------------------------------------------+
|                  ITERATION LOOP (max 4)                   |
|                                                           |
|  Phase 2: DEVELOPMENT                                     |
|    |                                                      |
|    |  Spawn FRESH developer agent                         |
|    |  Developer reads requirements.md                     |
|    |  N>1: also reads qa-review-(N-1).md                  |
|    |                                                      |
|    |  Developer implements changes                         |
|    |  Developer saves dev-summary-N.md                     |
|    |                                                      |
|    |  Team lead reads dev-summary-N.md                    |
|    |  If developer proposes a better approach or           |
|    |    flags something as infeasible -> team lead         |
|    |    evaluates and updates requirements.md if valid    |
|    |                                                      |
|    |  CLEANUP: delete dev-summary-N.md                    |
|    |           delete qa-review-(N-1).md if present       |
|    |                                                      |
|    |  ON DISK: requirements.md only                       |
|    |                                                      |
|    v                                                      |
|  Phase 3: QA REVIEW                                       |
|    |                                                      |
|    |  Spawn FRESH QA agent                                |
|    |  QA reads: requirements.md (only file on disk)       |
|    |  QA explores codebase independently                  |
|    |  QA reviews code against requirements                |
|    |  QA produces verdict: PASS / PASS WITH NOTES         |
|    |                        / NEEDS WORK                  |
|    |                                                      |
|    |  QA saves its review to qa-review-N.md               |
|    |                                                      |
|    v                                                      |
|  Phase 4: EVALUATION                                      |
|    |                                                      |
|    |  Team lead reads qa-review-N.md                      |
|    |                                                      |
|    +--- PASS (no critical/high) -------------------------+-> Exit loop
|    |                                                      |
|    +--- NEEDS WORK / critical findings                    |
|          |                                                |
|          |  Update requirements.md                        |
|          |  (fold in in-scope unresolved QA issues)       |
|          |  Conciseness pass over the update              |
|          |                                                |
|          |  ON DISK: requirements.md                      |
|          |           qa-review-N.md                        |
|          |    (kept so developer can read it next round)   |
|          |                                                |
|          +---- Loop back to Phase 2 (N++)                 |
|                                                           |
+-----------------------------------------------------------+
  |
  v
Phase 5: DOCUMENTATION (never skip)
  |
  |  Team lead writes docs itself
  |  (follows documentation skill)
  |
  v
Phase 5.5: CONCISENESS PASS
  |
  |  Re-read every doc just written
  |  Revise in place (conciseness skill)
  |
  v
Phase 6: COMMIT & PUSH
  |
  |  Delete .team-lead/ directory
  |  Stage changes, commit, push to main
  |  Conciseness pass over commit message
  |
  v
Phase 7: FINAL REPORT
  |
  |  Report: what was built, files changed,
  |    iteration count, remaining items, docs, commit SHA
  |
  v
DONE
```

## Step-by-Step Protocol

Before Phase 0, call `TaskCreate` to register all phases (0–7, including 1.5 and 5.5). Mark each in_progress on entry and completed on exit, so progress stays visible.

### The Conciseness Pass

Draft, then revise — as separate steps. Prose you just wrote reads as necessary to you; cutting it takes a fresh look at finished text.

After saving any draft: invoke the **conciseness skill**, re-read the file, edit in place, then move on. Load the skill once per run.

Applies to `requirements.md` (Phase 1 and each Phase 4 update), docs (Phase 5.5), the commit message (Phase 6), and the final report (Phase 7).

### Phase 0: Grill the User

Interview the user using the **grill-me skill** to extract requirements.

**Exit condition:** you can write acceptance criteria the user confirms. Summarize your understanding and get a final "go ahead" before proceeding.

### Phase 1: Planning

1. Explore the codebase for context — relevant files, project structure, existing patterns.
2. Synthesize the grilling session into a clear, actionable spec at `.team-lead/requirements.md`. It must include:
   - **Goal**: what we're building / fixing and why.
   - **Acceptance criteria**: a numbered checklist of concrete, testable conditions for "done".
   - **Scope boundaries**: what is explicitly out of scope.
   - **Relevant files**: key files the developer should read first.
3. Run the **Conciseness Pass** over `requirements.md`. A fresh developer reads it as their entire brief.
4. **Requirements may be revised post-investigation.** If a requirement doesn't hold up against the real codebase (scale, API reality, environment constraints), adjust `requirements.md`.

### Phase 1.5: Spec Review

Before spawning any developer, a fresh QA agent audits the spec itself:

```
Agent(prompt: <below>, description: "QA: spec review", model: "opus")
```

Prompt: read `.team-lead/requirements.md`, explore the codebase, and review the **spec, not code** (spec-review mode in your role) — ambiguous/untestable acceptance criteria, infeasible requirements, missing edge cases, scope gaps. Report findings directly with verdict **APPROVED** or **NEEDS REVISION**. Write no files.

Fold valid findings into `requirements.md`. On NEEDS REVISION with critical findings, re-review once — **max 2 rounds**, then proceed with the best spec you have.

### Phase 2: Development

Spawn a fresh developer agent every iteration:

```
Agent(
  prompt: <see below>,
  description: "Dev: iteration N",
  mode: "bypassPermissions",
  model: "sonnet" | "opus"
)
```

**Pick the model per task:** default to `sonnet` for straightforward implementation against a clear spec. Use `opus` only for genuinely hard work (complex refactors, tricky concurrency, perf-sensitive algorithms, deep debugging).

**Developer prompt must include:**
- Instruction to read `.team-lead/requirements.md`.
- On iteration N>1: instruction to also read `.team-lead/qa-review-(N-1).md` and address every developer-introduced item.
- Explicit instruction: "When finished, save a summary of all changes with file paths and line numbers to `.team-lead/dev-summary-N.md`."

Wait for the developer to finish. Read `.team-lead/dev-summary-N.md` to review the work.

If the developer flags a requirement as infeasible or proposes a better approach, evaluate it and update `requirements.md` before spawning QA — QA reviews against requirements, so stale requirements produce false negatives.

**Clean up before QA.** Delete `dev-summary-N.md` and `qa-review-(N-1).md` if present. Only `requirements.md` should remain on disk when the fresh QA spawns.

### Phase 3: QA Review

Spawn a fresh QA agent every iteration:

```
Agent(
  prompt: <see below>,
  description: "QA: review iteration N",
  model: "sonnet" | "opus"
)
```

**Pick the model per task:** default to `opus`. Use `sonnet` only for trivial tasks (isolated change, no architectural impact — e.g. copy tweaks, typo fixes, minor config, renames).

**Why fresh:** Fresh eyes catch regressions and avoid approval bias. This applies to both dev and QA — persistent agents accumulate context rot and drift from the spec.

**QA prompt must include:**
- Instruction to read `.team-lead/requirements.md` for the full spec.
- Explicit instruction: "Review the **entire application**, not just the developer's changes. Flag everything: architectural problems, dead code, missing tests, nonsensical abstractions, bad patterns — anything you find. Mark findings that exist independently of the developer's changes as `[PRE-EXISTING]`. Produce your review in the structured format defined in your role. Save your review to `.team-lead/qa-review-N.md`."

Wait for the QA to finish.

### Phase 4: Evaluation (Team Lead Decides)

Read the QA review. **Separate `[PRE-EXISTING]` findings from developer-introduced findings.**

**`[PRE-EXISTING]` findings:** Triage each one:
- **Trivial fix** (small, low-risk, clearly scoped): fold into the current iteration by adding it to `requirements.md` for the developer to fix in place.
- **Harmless** (no functional impact): ignore. Business value first — we need an app that works, not a perfect one.
- **Everything else:** file as a new GitHub issue via `gh issue create` and record the number for the final report.

**Developer-introduced findings** drive the pass/fail decision:

**Ship it (exit the loop) when ALL of these are true:**
- QA verdict is **PASS**.
- All acceptance criteria from requirements.md are met.
- No critical or high severity developer-introduced findings remain.

**Iterate (go back to Phase 2) otherwise**

**When iterating:**
1. Update `.team-lead/requirements.md` with refined/additional requirements based on developer-introduced findings only.
2. Be specific — tell the developer exactly what to fix, not "address QA feedback".
3. Include only the delta (what to change), not the full original spec again.
4. Run the **Conciseness Pass** over the updated file.
5. Go back to Phase 2 with the updated prompt.

**Hard limit: 4 iterations.** If critical issues remain after the 4th, stop and report to the user what's done and what remains.

### Phase 5: Documentation (Team Lead Writes Docs)

After the loop exits, **you write the documentation yourself** — you have the richest context for it.
Follow the **documentation skill** for conventions, structure, and templates. Write the draft here; don't self-edit for length yet.

### Phase 5.5: Conciseness Pass

Run the **Conciseness Pass** over every file Phase 5 touched, one at a time. Docs outlive everything else this loop produces and get read far more often than written.

### Phase 6: Commit & Push

Delete the `.team-lead/` directory first so working state doesn't land in the commit. Also delete any one-off/throwaway scripts the developer created during the loop. Stage all changes (including docs), write a commit message summarizing the work, commit, and push to `main`.

### Phase 7: Final Report

Report to the user:

- **What was built**: brief summary of the implementation.
- **Files changed**: modified/created files.
- **Iterations**: how many dev+QA rounds it took and why.
- **GitHub issues filed**: numbers and titles of issues opened for `[PRE-EXISTING]` findings.
- **Remaining items**: low/medium developer-introduced findings deliberately skipped (and why).
- **Documentation**: what docs were created/updated.
- **Commit**: SHA pushed to `main`.

Run the **Conciseness Pass** over this report before sending it.

## Rules for the Team Lead

- **Never write code.** Your job is requirements, evaluation, coordination, and documentation. The only files you create are `requirements.md` and docs — never source code.
- **Never ship a first draft.** Every document gets a Conciseness Pass before you move on.
