---
name: conciseness
description: "Write and edit prose that stays short without losing meaning. Use whenever you are drafting or revising anything that gets read repeatedly — skill files, instructions, docs, READMEs, comments, PR descriptions, commit messages — or when the user asks to tighten, trim, deduplicate, or 'make this concise'."
---

# Conciseness

Text read many times pays its length back on every read. Aim for the shortest version a careful reader still fully understands — trimming past that costs clarity, so stop there. Three rules do most of the work:

**Use as few words as needed.** Cut words that don't change the meaning: filler ("in order to" → "to"), hedges, throat-clearing intros, restating the obvious. Test any word or sentence by removing it — if the meaning survives, leave it out.

**Say each thing once.** State each fact, rule, or instruction in one place. Duplication isn't emphasis — it's debt: copies drift apart, and the reader can't tell which is authoritative. When sections overlap, keep the better one and delete or link the other.

**Drop defensive padding.** Shouting (`ALWAYS`, `NEVER SKIP`, `!!!`, "or you are violating the contract") doesn't earn compliance — it adds noise and signals distrust. Neither does warning against what can't happen: "don't return a severity field" when the schema has none, or "don't touch the database" in a tool with no database access. State the rule plainly, once, with the reason it matters; when the format or context already rules something out, cut the warning.

This isn't terseness. Keep the words that carry meaning — the *why* behind a rule, a needed caveat, a concrete example. Aim for high signal per word, not the lowest count.
